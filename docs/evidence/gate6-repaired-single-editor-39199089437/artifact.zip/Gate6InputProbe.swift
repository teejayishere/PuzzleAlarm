
import SwiftUI
import UIKit

@MainActor
final class Gate6WindowProbe: UIGestureRecognizer {
    override func canPrevent(_ other: UIGestureRecognizer) -> Bool { false }
    override func canBePrevented(by other: UIGestureRecognizer) -> Bool { false }
    private func record(_ touches: Set<UITouch>, _ phase: String) {
        guard let window = view as? UIWindow else { return }
        for touch in touches {
            var current = touch.view
            UITestEnvironment.traceToggle("touch \(phase) timestamp=\(touch.timestamp) point=\(touch.location(in: window)) window=\(ObjectIdentifier(window)) app=\(UIApplication.shared.applicationState.rawValue) scene=\(window.windowScene?.activationState.rawValue ?? -99)")
            var depth = 0
            while let item = current, depth < 24 {
                UITestEnvironment.traceToggle("ancestor phase=\(phase) depth=\(depth) object=\(ObjectIdentifier(item)) type=\(type(of: item)) id=\(item.accessibilityIdentifier ?? "none")")
                let gestures = item.gestureRecognizers ?? []
                // Enumerate the entire snapshot. The fixed recorder capacity is
                // the bound: exhaustion increments overflow and fail-stops, never wraps.
                UITestEnvironment.traceToggle("gesture list depth=\(depth) count=\(gestures.count)")
                for (index, gesture) in gestures.enumerated() {
                    UITestEnvironment.traceToggle("gesture depth=\(depth) index=\(index) object=\(ObjectIdentifier(gesture)) type=\(type(of: gesture)) state=\(gesture.state.rawValue) enabled=\(gesture.isEnabled)")
                }
                current = item.superview
                depth += 1
            }
            if current != nil { UITestEnvironment.traceToggle("capture limited ancestors") }
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) { record(touches, "began") }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent) { record(touches, "ended"); state = .failed }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent) { record(touches, "cancelled"); state = .failed }
}

@MainActor
struct Gate6WindowBridge: UIViewRepresentable {
    final class Host: UIView {
        private var observingLifecycle = false
        @objc private func lifecycle(_ notification: Notification) {
            UITestEnvironment.traceToggle("lifecycle name=\(notification.name.rawValue) app=\(UIApplication.shared.applicationState.rawValue) scene=\(window?.windowScene?.activationState.rawValue ?? -99)")
        }
        override func didMoveToWindow() {
            super.didMoveToWindow()
            if !observingLifecycle {
                observingLifecycle = true
                for name in [UIApplication.willResignActiveNotification,
                             UIApplication.didEnterBackgroundNotification,
                             UIApplication.willEnterForegroundNotification,
                             UIApplication.didBecomeActiveNotification,
                             UIApplication.willTerminateNotification,
                             UIScene.willDeactivateNotification,
                             UIScene.didEnterBackgroundNotification,
                             UIScene.willEnterForegroundNotification,
                             UIScene.didActivateNotification] {
                    NotificationCenter.default.addObserver(self, selector: #selector(lifecycle(_:)), name: name, object: nil)
                }
                UITestEnvironment.traceToggle("lifecycle observing app=\(UIApplication.shared.applicationState.rawValue) scene=\(window?.windowScene?.activationState.rawValue ?? -99)")
            }
            guard let window, !(window.gestureRecognizers ?? []).contains(where: { $0 is Gate6WindowProbe }) else { return }
            let probe = Gate6WindowProbe(target: nil, action: nil)
            probe.cancelsTouchesInView = false; probe.delaysTouchesBegan = false; probe.delaysTouchesEnded = false
            window.addGestureRecognizer(probe)
            UITestEnvironment.traceToggle("probe attached window=\(ObjectIdentifier(window)) scene=\(window.windowScene?.activationState.rawValue ?? -99)")
        }
    }
    func makeUIView(context: Context) -> Host { Host() }
    func updateUIView(_ uiView: Host, context: Context) {}
}

@MainActor
final class Gate6TraceSwitch: UISwitch {
    override func didMoveToWindow() {
        super.didMoveToWindow()
        UITestEnvironment.traceToggle("switch attached=\(window != nil) id=\(ObjectIdentifier(self)) targets=\(allTargets.count)")
    }
}
