PuzzleAlarm actual iPhone Simulator visual demo

Windows: right-click the downloaded ZIP > Extract All. Open index.html in the extracted folder.
Or open any numbered PNG directly in Photos. No Xcode, Mac or xcresult viewer is required.
The gallery is an offline still-image walkthrough; no video was recorded.
DEBUG fixtures simulate scheduler/camera effects. Physical device verification: NOT RUN.
Capture commit: f01abf42c7b4e7a7ed10bb926bb736ebaa8e77bc
CI: https://github.com/teejayishere/PuzzleAlarm/actions/runs/40521565094
