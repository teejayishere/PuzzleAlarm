swift package dump-package
